import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ChangeDetectorRef, ChangeDetectionStrategy, NgZone,
  ElementRef, ViewChild
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

// ════════════════════════════════════════════════
//  THEME 2 — CELESTIAL GOLDEN HOUR
//  Midnight Navy · Liquid Gold · Champagne · Starlight
// ════════════════════════════════════════════════

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventComponent implements OnInit, OnDestroy, AfterViewInit {

  // ── Data ───────────────────────────────────────────
  event: any = null;
  mapUrl!: SafeResourceUrl;
  isPlaying = false;
  rsvpSubmitted = false;

  // ── Canvas refs ────────────────────────────────────
  @ViewChild('starCanvas')    private starCanvasRef!:    ElementRef<HTMLCanvasElement>;
  @ViewChild('auroraCanvas')  private auroraCanvasRef!:  ElementRef<HTMLCanvasElement>;
  @ViewChild('fireflyCanvas') private fireflyCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('moonContainer') private moonContainerRef!: ElementRef<HTMLElement>;

  // ── Hero typewriter ────────────────────────────────
  displayGroom = '';
  displayBride = '';
  private typeIntervals: any[] = [];
  private typeTimeouts:  any[] = [];

  // ── Countdown ──────────────────────────────────────
  countdown     = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  prevCountdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  private timerInterval: any;

  // ── Gallery ────────────────────────────────────────
  galleryIndex = 0;
  private galleryAutoInterval: any;

  // ── Lightbox ───────────────────────────────────────
  showLightbox  = false;
  currentIndex  = 0;
  currentImage  = '';

  // ── Animation RAF ids ─────────────────────────────
  private starRafId:    number = 0;
  private fireflyRafId: number = 0;
  private auroraRafId:  number = 0;

  // ── Scroll observer ───────────────────────────────
  private scrollObserver!: IntersectionObserver;
  private resizeListener!: () => void;

  constructor(
    private route:     ActivatedRoute,
    private api:       ApiService,
    private sanitizer: DomSanitizer,
    private cdr:       ChangeDetectorRef,
    private ngZone:    NgZone
  ) {}

  // ════════════════════════════════════════════════
  //  LIFECYCLE
  // ════════════════════════════════════════════════

  ngOnInit() {
    const slug = this.route.snapshot.paramMap.get('slug');
    this.api.getEvent(slug!).subscribe(res => {
      this.event = res;

      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${encodeURIComponent(res.location)}&output=embed`
      );

      this.startCountdown();

      setTimeout(() => {
        this.animateNames();
        this.cdr.detectChanges();
      }, 1400);

      this.cdr.detectChanges();
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initStarCanvas();
      this.initAuroraCanvas();
      this.initFireflyCanvas();
      this.initScrollObserver();
      this.initMoonParallax();
      this.startGalleryAuto();
    }, 600);
  }

  ngOnDestroy() {
    clearInterval(this.timerInterval);
    clearInterval(this.galleryAutoInterval);
    this.typeIntervals.forEach(clearInterval);
    this.typeTimeouts.forEach(clearTimeout);
    cancelAnimationFrame(this.starRafId);
    cancelAnimationFrame(this.fireflyRafId);
    cancelAnimationFrame(this.auroraRafId);
    this.scrollObserver?.disconnect();
    window.removeEventListener('resize', this.resizeListener);
    window.removeEventListener('scroll', this.scrollListener);
  }

  // ════════════════════════════════════════════════
  //  TYPEWRITER NAMES
  // ════════════════════════════════════════════════

  private animateNames() {
    const groom = this.event?.groom || '';
    const bride = this.event?.bride || '';
    let i = 0;

    const gi = setInterval(() => {
      if (i < groom.length) {
        this.displayGroom += groom[i++];
        this.cdr.detectChanges();
      } else {
        clearInterval(gi);
        const t = setTimeout(() => {
          let j = 0;
          const bi = setInterval(() => {
            if (j < bride.length) {
              this.displayBride += bride[j++];
              this.cdr.detectChanges();
            } else clearInterval(bi);
          }, 100);
          this.typeIntervals.push(bi);
        }, 500);
        this.typeTimeouts.push(t);
      }
    }, 100);
    this.typeIntervals.push(gi);
  }

  // ════════════════════════════════════════════════
  //  COUNTDOWN
  // ════════════════════════════════════════════════

  private startCountdown() {
    const target = new Date(this.event.date + 'T16:00:00');
    const run = () => {
      const diff = target.getTime() - Date.now();
      if (diff > 0) {
        const next = {
          days:    Math.floor(diff / 86_400_000),
          hours:   Math.floor((diff % 86_400_000) / 3_600_000),
          minutes: Math.floor((diff % 3_600_000)  / 60_000),
          seconds: Math.floor((diff % 60_000)     / 1_000),
        };
        this.prevCountdown = { ...this.countdown };
        this.countdown = next;
        this.cdr.detectChanges();
      } else {
        clearInterval(this.timerInterval);
      }
    };
    run();
    this.timerInterval = setInterval(run, 1000);
  }

  get fDays():    string { return String(this.countdown.days).padStart(3, '0'); }
  get fHours():   string { return String(this.countdown.hours).padStart(2, '0'); }
  get fMinutes(): string { return String(this.countdown.minutes).padStart(2, '0'); }
  get fSeconds(): string { return String(this.countdown.seconds).padStart(2, '0'); }

  tickDays():    boolean { return this.countdown.days    !== this.prevCountdown.days; }
  tickHours():   boolean { return this.countdown.hours   !== this.prevCountdown.hours; }
  tickMinutes(): boolean { return this.countdown.minutes !== this.prevCountdown.minutes; }
  tickSeconds(): boolean { return this.countdown.seconds !== this.prevCountdown.seconds; }

  // ════════════════════════════════════════════════
  //  GALLERY
  // ════════════════════════════════════════════════

  get galleryImages(): string[] { return this.event?.gallery || []; }
  get galleryDots():   number[] { return this.galleryImages.map((_, i) => i); }

  get galleryTranslate(): string {
    return `translateX(-${this.galleryIndex * 100}%)`;
  }

  goToSlide(n: number) {
    this.galleryIndex = ((n % this.galleryImages.length) + this.galleryImages.length) % this.galleryImages.length;
    this.cdr.detectChanges();
    this.resetGalleryAuto();
  }

  prevSlide() { this.goToSlide(this.galleryIndex - 1); }
  nextSlide() { this.goToSlide(this.galleryIndex + 1); }

  private startGalleryAuto() {
    this.galleryAutoInterval = setInterval(() => {
      this.galleryIndex = (this.galleryIndex + 1) % Math.max(this.galleryImages.length, 1);
      this.cdr.detectChanges();
    }, 5000);
  }

  private resetGalleryAuto() {
    clearInterval(this.galleryAutoInterval);
    this.startGalleryAuto();
  }

  // ════════════════════════════════════════════════
  //  LIGHTBOX
  // ════════════════════════════════════════════════

  openLightbox(index: number) {
    this.currentIndex = index;
    this.currentImage = this.event.gallery[index];
    this.showLightbox = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }

  closeLightbox(event?: MouseEvent) {
    if (!event || (event.target as HTMLElement).classList.contains('lb-overlay')) {
      this.showLightbox = false;
      document.body.style.overflow = '';
      this.cdr.detectChanges();
    }
  }

  prevLightbox() {
    this.currentIndex = (this.currentIndex - 1 + this.event.gallery.length) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  nextLightbox() {
    this.currentIndex = (this.currentIndex + 1) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  // ════════════════════════════════════════════════
  //  MUSIC
  // ════════════════════════════════════════════════

  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) { audio.pause(); }
      else { await audio.play(); }
      this.isPlaying = !this.isPlaying;
      this.cdr.detectChanges();
    } catch (e) { console.warn(e); }
  }

  // ════════════════════════════════════════════════
  //  RSVP
  // ════════════════════════════════════════════════

  submitRsvp(e: Event) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name:       (form.querySelector('[name="name"]')       as HTMLInputElement).value,
      phone:      (form.querySelector('[name="phone"]')      as HTMLInputElement).value,
      guestCount: Number((form.querySelector('[name="guestCount"]') as HTMLInputElement)?.value || 1),
      attending:  (form.querySelector('[name="attending"]')  as HTMLSelectElement).value === 'true',
      eventId:    this.event._id,
    };
    this.api.submitRSVP(data).subscribe(() => {
      this.rsvpSubmitted = true;
      this.cdr.detectChanges();
      // Animate constellation in success state
      setTimeout(() => this.buildSuccessConstellation(), 100);
    });
  }

  private buildSuccessConstellation() {
    const container = document.querySelector('.rs-constellation') as HTMLElement;
    if (!container) return;
    const stars = [
      {x:40,y:10,r:5,delay:0.1},{x:70,y:30,r:3,delay:0.2},{x:10,y:35,r:3.5,delay:0.3},
      {x:55,y:55,r:4,delay:0.4},{x:25,y:62,r:3,delay:0.5},{x:75,y:65,r:3.5,delay:0.6},
    ];
    const lines = [
      {x1:40,y1:10,x2:70,y2:30,delay:0.25},{x1:40,y1:10,x2:10,y2:35,delay:0.35},
      {x1:70,y1:30,x2:55,y2:55,delay:0.45},{x1:10,y1:35,x2:25,y2:62,delay:0.55},
      {x1:55,y1:55,x2:75,y2:65,delay:0.65},
    ];
    let html = '';
    lines.forEach(l => {
      const dx = l.x2-l.x1, dy = l.y2-l.y1;
      const len = Math.sqrt(dx*dx+dy*dy);
      const ang = Math.atan2(dy,dx)*180/Math.PI;
      html += `<div class="rs-line" style="width:${len}px;top:${l.y1}px;left:${l.x1}px;transform:rotate(${ang}deg);animation-delay:${l.delay}s"></div>`;
    });
    stars.forEach(s => {
      html += `<div class="rs-star" style="width:${s.r*2}px;height:${s.r*2}px;top:${s.y-s.r}px;left:${s.x-s.r}px;animation-delay:${s.delay}s"></div>`;
    });
    container.innerHTML = html;
  }

  // ════════════════════════════════════════════════
  //  SCROLL REVEAL
  // ════════════════════════════════════════════════

  private initScrollObserver() {
    this.scrollObserver = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          this.scrollObserver.unobserve(e.target);
        }
      }),
      { threshold: 0.07 }
    );
    document.querySelectorAll('.fade-up').forEach(el => this.scrollObserver.observe(el));
  }

  // ════════════════════════════════════════════════
  //  MOON PARALLAX
  // ════════════════════════════════════════════════

  private scrollListener = () => {
    const moon = this.moonContainerRef?.nativeElement;
    if (moon) moon.style.transform = `translateY(${window.scrollY * 0.12}px)`;
  };

  private initMoonParallax() {
    window.addEventListener('scroll', this.scrollListener, { passive: true });
  }

  // ════════════════════════════════════════════════
  //  STAR CANVAS — milky way + twinkling constellation stars
  // ════════════════════════════════════════════════

  private initStarCanvas() {
    const canvas = this.starCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d')!;
    let stars: any[] = [];
    let constellations: any[] = [];
    let t = 0;

    const resize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      buildStars();
      buildConstellations();
    };

    const buildStars = () => {
      stars = [];
      const count = Math.floor((canvas.width * canvas.height) / 4000);
      for (let i = 0; i < count; i++) {
        stars.push({
          x:     Math.random() * canvas.width,
          y:     Math.random() * canvas.height * 0.85,
          r:     Math.random() * 1.6 + 0.3,
          speed: Math.random() * 0.006 + 0.002,
          phase: Math.random() * Math.PI * 2,
          color: Math.random() > 0.85 ? '#fff0c8' : (Math.random() > 0.7 ? '#c8e0ff' : '#ffffff'),
        });
      }
    };

    const buildConstellations = () => {
      constellations = [];
      const groups = [
        [[0.15,0.12],[0.22,0.08],[0.28,0.14],[0.24,0.20],[0.18,0.22]],
        [[0.65,0.10],[0.72,0.06],[0.78,0.12],[0.75,0.18],[0.68,0.20],[0.63,0.15]],
        [[0.40,0.05],[0.46,0.09],[0.50,0.04],[0.54,0.09],[0.44,0.18]],
        [[0.85,0.25],[0.90,0.18],[0.88,0.30],[0.93,0.28],[0.95,0.22]],
      ];
      groups.forEach(pts => {
        const nodes = pts.map(p => ({ x: p[0]*canvas.width, y: p[1]*canvas.height }));
        const edges: number[][] = [];
        for (let i = 0; i < nodes.length-1; i++) edges.push([i, i+1]);
        constellations.push({ nodes, edges });
      });
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      t += 0.01;

      // Milky way haze
      const mw = ctx.createLinearGradient(0, 0, canvas.width*0.8, canvas.height*0.5);
      mw.addColorStop(0, 'transparent');
      mw.addColorStop(0.4, 'rgba(232,184,48,0.022)');
      mw.addColorStop(0.6, 'rgba(200,220,255,0.018)');
      mw.addColorStop(1, 'transparent');
      ctx.fillStyle = mw;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars
      stars.forEach(s => {
        const alpha = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * s.speed * 60 + s.phase));
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
        ctx.fillStyle = s.color;
        ctx.fill();
        if (s.r > 1.2) {
          const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.r*3);
          g.addColorStop(0, `rgba(232,184,48,${alpha*0.2})`);
          g.addColorStop(1, 'transparent');
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r*3, 0, Math.PI*2);
          ctx.fillStyle = g;
          ctx.fill();
        }
      });

      // Constellations
      ctx.globalAlpha = 0.25 + 0.1 * Math.sin(t * 0.3);
      constellations.forEach(c => {
        c.edges.forEach(([a, b]: number[]) => {
          ctx.beginPath();
          ctx.moveTo(c.nodes[a].x, c.nodes[a].y);
          ctx.lineTo(c.nodes[b].x, c.nodes[b].y);
          ctx.strokeStyle = 'rgba(232,184,48,0.3)';
          ctx.lineWidth = 0.5;
          ctx.stroke();
        });
        c.nodes.forEach((n: any) => {
          ctx.beginPath();
          ctx.arc(n.x, n.y, 2.5, 0, Math.PI*2);
          ctx.fillStyle = 'rgba(252,233,138,0.9)';
          ctx.fill();
          const g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, 8);
          g.addColorStop(0, 'rgba(232,184,48,0.3)');
          g.addColorStop(1, 'transparent');
          ctx.beginPath();
          ctx.arc(n.x, n.y, 8, 0, Math.PI*2);
          ctx.fillStyle = g;
          ctx.fill();
        });
      });

      ctx.globalAlpha = 1;
      this.starRafId = requestAnimationFrame(draw);
    };

    this.resizeListener = resize;
    window.addEventListener('resize', resize);
    this.ngZone.runOutsideAngular(() => { resize(); draw(); });
  }

  // ════════════════════════════════════════════════
  //  FIREFLY CANVAS — 55 wandering bioluminescent particles
  // ════════════════════════════════════════════════

  private initFireflyCanvas() {
    const canvas = this.fireflyCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d')!;
    let flies: any[] = [];
    let t = 0;

    const resize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      buildFlies();
    };

    const buildFlies = () => {
      flies = [];
      const count = Math.min(55, Math.floor(window.innerWidth / 25));
      const colors = ['rgba(232,184,48,','rgba(245,208,96,','rgba(252,233,138,'];
      for (let i = 0; i < count; i++) {
        flies.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random()-0.5) * 0.5,
          vy: (Math.random()-0.5) * 0.4,
          r: Math.random() * 2.5 + 1,
          phase: Math.random() * Math.PI * 2,
          speed: Math.random() * 0.025 + 0.01,
          trail: [] as any[],
          maxTrail: Math.floor(Math.random()*8+4),
          color: colors[Math.floor(Math.random()*colors.length)],
        });
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      t += 0.016;

      flies.forEach(f => {
        f.vx += (Math.random()-0.5)*0.08;
        f.vy += (Math.random()-0.5)*0.06;
        f.vx *= 0.96; f.vy *= 0.96;
        f.x += f.vx; f.y += f.vy;
        if (f.x < -10) f.x = canvas.width+10;
        if (f.x > canvas.width+10) f.x = -10;
        if (f.y < -10) f.y = canvas.height+10;
        if (f.y > canvas.height+10) f.y = -10;
        f.trail.push({ x: f.x, y: f.y });
        if (f.trail.length > f.maxTrail) f.trail.shift();

        const blink = 0.15 + 0.85 * (0.5 + 0.5 * Math.sin(t * f.speed * 60 + f.phase));

        for (let i = 1; i < f.trail.length; i++) {
          const a = (i / f.trail.length) * blink * 0.3;
          ctx.beginPath();
          ctx.moveTo(f.trail[i-1].x, f.trail[i-1].y);
          ctx.lineTo(f.trail[i].x, f.trail[i].y);
          ctx.strokeStyle = f.color + a + ')';
          ctx.lineWidth = f.r * 0.4;
          ctx.stroke();
        }

        const glow = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.r*5);
        glow.addColorStop(0, f.color + (blink*0.6) + ')');
        glow.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r*5, 0, Math.PI*2);
        ctx.fillStyle = glow;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r*blink, 0, Math.PI*2);
        ctx.fillStyle = f.color + (blink*0.95) + ')';
        ctx.fill();
      });

      this.fireflyRafId = requestAnimationFrame(draw);
    };

    window.addEventListener('resize', resize);
    this.ngZone.runOutsideAngular(() => { resize(); draw(); });
  }

  // ════════════════════════════════════════════════
  //  AURORA CANVAS — 3-layer northern lights
  // ════════════════════════════════════════════════

  private initAuroraCanvas() {
    const canvas = this.auroraCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d')!;
    let t = 0;

    const resize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    const bands = [
      { cy: 0.15, spread: 0.22, a: 0.055, c1: 'rgba(100,200,180,', c2: 'rgba(100,160,220,' },
      { cy: 0.08, spread: 0.16, a: 0.035, c1: 'rgba(180,120,255,', c2: 'rgba(140,180,255,' },
      { cy: 0.25, spread: 0.18, a: 0.030, c1: 'rgba(80,220,160,',  c2: 'rgba(200,180,255,' },
    ];

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      t += 0.003;
      const W = canvas.width, H = canvas.height;

      bands.forEach((band, bi) => {
        for (let x = 0; x < W; x += 3) {
          const wave =
            Math.sin(x*0.008 + t + bi*1.4) * 0.5 +
            Math.sin(x*0.003 + t*1.3 + bi*0.8) * 0.3 +
            Math.sin(x*0.02  + t*0.7 + bi*2.1) * 0.2;
          const cy   = band.cy * H + wave * H * 0.06;
          const amp  = band.spread * H * (0.7 + 0.3 * Math.sin(x*0.005 + t*0.6 + bi));
          const intA = band.a * (0.5 + 0.5 * Math.abs(wave));

          const g = ctx.createLinearGradient(x, cy-amp, x, cy+amp);
          g.addColorStop(0,    'transparent');
          g.addColorStop(0.35, band.c1 + intA + ')');
          g.addColorStop(0.5,  band.c2 + (intA*1.2) + ')');
          g.addColorStop(0.65, band.c1 + intA + ')');
          g.addColorStop(1,    'transparent');
          ctx.fillStyle = g;
          ctx.fillRect(x, cy-amp, 3, amp*2);
        }
      });

      this.auroraRafId = requestAnimationFrame(draw);
    };

    this.ngZone.runOutsideAngular(() => draw());
  }
}