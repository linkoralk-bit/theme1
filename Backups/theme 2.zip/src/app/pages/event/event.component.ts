import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ChangeDetectorRef, ChangeDetectionStrategy
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventComponent implements OnInit, OnDestroy, AfterViewInit {

  event: any = null;
  mapUrl!: SafeResourceUrl;
  isPlaying = false;
  loaderVisible = true;
  heroReady = false;

  // Typewriter
  displayGroom = '';
  displayBride = '';
  private typeIntervals: any[] = [];
  private typeTimeouts: any[] = [];

  // Countdown
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  prevCountdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  private timerInterval: any;

  // Lightbox
  showLightbox = false;
  currentIndex = 0;
  currentImage = '';

  // RSVP
  rsvpSubmitted = false;

  // Petals
  petals: {
    x: number; size: number; delay: number;
    duration: number; colorIdx: number; rotate: number;
  }[] = [];

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generatePetals();

    const slug = this.route.snapshot.paramMap.get('slug');
    this.api.getEvent(slug!).subscribe((res) => {
      this.event = res;

      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${encodeURIComponent(this.event.location)}&output=embed`
      );

      // Hide loader after minimum display time
      setTimeout(() => {
        this.loaderVisible = false;
        this.heroReady = true;
        this.cdr.detectChanges();
        this.animateNames();
        this.startCountdown();
      }, 1800);

      this.cdr.detectChanges();
    });
  }

  ngAfterViewInit() {
    setTimeout(() => this.initScrollObserver(), 2200);
  }

  // ── PETALS ──────────────────────────────────────────
  generatePetals() {
    this.petals = Array.from({ length: 22 }, (_, i) => ({
      x: Math.random() * 100,
      size: Math.random() * 8 + 4,
      delay: Math.random() * 14,
      duration: Math.random() * 12 + 9,
      colorIdx: i % 4,
      rotate: Math.random() * 360,
    }));
  }

  get petalColors(): string[] {
    return [
      'rgba(212,114,122,0.55)',
      'rgba(232,160,160,0.45)',
      'rgba(245,230,232,0.35)',
      'rgba(196,80,96,0.45)',
    ];
  }

  // ── TYPEWRITER ───────────────────────────────────────
  animateNames() {
    const groom = this.event?.groom || '';
    const bride = this.event?.bride || '';
    let i = 0;

    const groomInterval = setInterval(() => {
      if (i < groom.length) {
        this.displayGroom += groom[i++];
        this.cdr.detectChanges();
      } else {
        clearInterval(groomInterval);
        const t = setTimeout(() => this.typeBride(bride), 480);
        this.typeTimeouts.push(t);
      }
    }, 95);

    this.typeIntervals.push(groomInterval);
  }

  private typeBride(bride: string) {
    let j = 0;
    const brideInterval = setInterval(() => {
      if (j < bride.length) {
        this.displayBride += bride[j++];
        this.cdr.detectChanges();
      } else {
        clearInterval(brideInterval);
      }
    }, 95);
    this.typeIntervals.push(brideInterval);
  }

  // ── COUNTDOWN ────────────────────────────────────────
  startCountdown() {
    const weddingDate = new Date(this.event.date + 'T16:00:00');

    const update = () => {
      const diff = weddingDate.getTime() - Date.now();
      if (diff > 0) {
        const next = {
          days:    Math.floor(diff / 86_400_000),
          hours:   Math.floor((diff % 86_400_000) / 3_600_000),
          minutes: Math.floor((diff % 3_600_000)  / 60_000),
          seconds: Math.floor((diff % 60_000)     / 1_000),
        };
        this.prevCountdown = { ...this.countdown };
        this.countdown = next;
        this.cdr.detectChanges();
      } else {
        clearInterval(this.timerInterval);
      }
    };

    update();
    this.timerInterval = setInterval(update, 1000);
  }

  get fDays():    string { return String(this.countdown.days).padStart(3, '0'); }
  get fHours():   string { return String(this.countdown.hours).padStart(2, '0'); }
  get fMinutes(): string { return String(this.countdown.minutes).padStart(2, '0'); }
  get fSeconds(): string { return String(this.countdown.seconds).padStart(2, '0'); }

  daysTick():    boolean { return this.countdown.days    !== this.prevCountdown.days; }
  hoursTick():   boolean { return this.countdown.hours   !== this.prevCountdown.hours; }
  minutesTick(): boolean { return this.countdown.minutes !== this.prevCountdown.minutes; }
  secondsTick(): boolean { return this.countdown.seconds !== this.prevCountdown.seconds; }

  // ── SCROLL OBSERVER ──────────────────────────────────
  initScrollObserver() {
    const io = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          io.unobserve(e.target);
        }
      }),
      { threshold: 0.08 }
    );
    document.querySelectorAll('.fade-up').forEach(el => io.observe(el));
  }

  // ── LIGHTBOX ─────────────────────────────────────────
  openLightbox(index: number) {
    this.currentIndex = index;
    this.currentImage = this.event.gallery[index];
    this.showLightbox = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }

  closeLightbox(event?: MouseEvent) {
    if (!event || (event.target as HTMLElement).classList.contains('lightbox-overlay')) {
      this.showLightbox = false;
      document.body.style.overflow = '';
      this.cdr.detectChanges();
    }
  }

  prevImage() {
    this.currentIndex = (this.currentIndex - 1 + this.event.gallery.length) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  nextImage() {
    this.currentIndex = (this.currentIndex + 1) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  // ── MUSIC ─────────────────────────────────────────────
  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) {
        audio.pause();
      } else {
        await audio.play();
      }
      this.isPlaying = !this.isPlaying;
      this.cdr.detectChanges();
    } catch (e) {
      console.warn('Audio blocked:', e);
    }
  }

  // ── RSVP ──────────────────────────────────────────────
  submitForm(e: Event) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name:      (form[0] as HTMLInputElement).value,
      phone:     (form[1] as HTMLInputElement).value,
      attending: (form[2] as HTMLSelectElement).value === 'true',
      eventId:   this.event._id,
    };

    this.api.submitRSVP(data).subscribe(() => {
      this.rsvpSubmitted = true;
      this.cdr.detectChanges();
    });
  }

  // ── CLEANUP ───────────────────────────────────────────
  ngOnDestroy() {
    clearInterval(this.timerInterval);
    this.typeIntervals.forEach(clearInterval);
    this.typeTimeouts.forEach(clearTimeout);
  }
}