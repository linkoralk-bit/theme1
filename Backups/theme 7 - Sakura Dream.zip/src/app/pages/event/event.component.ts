import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ChangeDetectorRef, ChangeDetectionStrategy, NgZone,
  ElementRef, ViewChild
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

// ════════════════════════════════════════════════════════════
//  THEME 3 — SAKURA DREAM
//  Cinematic Japanese cherry-blossom fantasy
//  Ink Black · Sakura Pink · Warm Gold · Ivory
// ════════════════════════════════════════════════════════════

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventComponent implements OnInit, OnDestroy, AfterViewInit {

  // ── Data ──────────────────────────────────────────────────
  event: any = null;
  mapUrl!: SafeResourceUrl;
  isPlaying    = false;
  rsvpSubmitted = false;

  // ── Canvas refs ───────────────────────────────────────────
  @ViewChild('petalCanvas')   private petalCanvasRef!:   ElementRef<HTMLCanvasElement>;
  @ViewChild('lanternCanvas') private lanternCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('rsBloomRef')    private rsBloomRef!:       ElementRef<HTMLElement>;

  // ── Typewriter ────────────────────────────────────────────
  displayGroom = '';
  displayBride = '';
  private typeIntervals: any[] = [];
  private typeTimeouts:  any[] = [];

  // ── Countdown ─────────────────────────────────────────────
  countdown     = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  prevCountdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  private timerInterval: any;

  // ── Gallery ───────────────────────────────────────────────
  galleryIndex = 0;
  private galleryAutoInterval: any;

  // ── Lightbox ──────────────────────────────────────────────
  showLightbox = false;
  currentIndex = 0;
  currentImage = '';

  // ── RAF ids ───────────────────────────────────────────────
  private petalRafId:   number = 0;
  private lanternRafId: number = 0;

  // ── Observers / listeners ─────────────────────────────────
  private scrollObserver!: IntersectionObserver;
  private resizeFn!: () => void;

  constructor(
    private route:     ActivatedRoute,
    private api:       ApiService,
    private sanitizer: DomSanitizer,
    private cdr:       ChangeDetectorRef,
    private ngZone:    NgZone
  ) {}

  // ══════════════════════════════════════════════════════════
  //  LIFECYCLE
  // ══════════════════════════════════════════════════════════

  ngOnInit() {
    const slug = this.route.snapshot.paramMap.get('slug');
    this.api.getEvent(slug!).subscribe(res => {
      this.event = res;
      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${encodeURIComponent(res.location)}&output=embed`
      );
      this.startCountdown();
      setTimeout(() => { this.animateNames(); this.cdr.detectChanges(); }, 1800);
      this.cdr.detectChanges();
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initPetalCanvas();
      this.initLanternCanvas();
      this.initScrollReveal();
      this.startGalleryAuto();
    }, 700);
  }

  ngOnDestroy() {
    clearInterval(this.timerInterval);
    clearInterval(this.galleryAutoInterval);
    this.typeIntervals.forEach(clearInterval);
    this.typeTimeouts.forEach(clearTimeout);
    cancelAnimationFrame(this.petalRafId);
    cancelAnimationFrame(this.lanternRafId);
    this.scrollObserver?.disconnect();
    if (this.resizeFn) window.removeEventListener('resize', this.resizeFn);
  }

  // ══════════════════════════════════════════════════════════
  //  TYPEWRITER NAMES
  // ══════════════════════════════════════════════════════════

  private animateNames() {
    const groom = this.event?.groom || '';
    const bride = this.event?.bride || '';
    let i = 0;
    const gi = setInterval(() => {
      if (i < groom.length) { this.displayGroom += groom[i++]; this.cdr.detectChanges(); }
      else {
        clearInterval(gi);
        const t = setTimeout(() => {
          let j = 0;
          const bi = setInterval(() => {
            if (j < bride.length) { this.displayBride += bride[j++]; this.cdr.detectChanges(); }
            else clearInterval(bi);
          }, 110);
          this.typeIntervals.push(bi);
        }, 600);
        this.typeTimeouts.push(t);
      }
    }, 110);
    this.typeIntervals.push(gi);
  }

  // ══════════════════════════════════════════════════════════
  //  COUNTDOWN
  // ══════════════════════════════════════════════════════════

  private startCountdown() {
    const target = new Date(this.event.date + 'T16:00:00');
    const run = () => {
      const diff = target.getTime() - Date.now();
      if (diff <= 0) { clearInterval(this.timerInterval); return; }
      const next = {
        days:    Math.floor(diff / 86_400_000),
        hours:   Math.floor((diff % 86_400_000) / 3_600_000),
        minutes: Math.floor((diff % 3_600_000)  / 60_000),
        seconds: Math.floor((diff % 60_000)     / 1_000),
      };
      this.prevCountdown = { ...this.countdown };
      this.countdown = next;
      this.cdr.detectChanges();
    };
    run();
    this.timerInterval = setInterval(run, 1000);
  }

  get fDays():    string { return String(this.countdown.days).padStart(3, '0'); }
  get fHours():   string { return String(this.countdown.hours).padStart(2, '0'); }
  get fMinutes(): string { return String(this.countdown.minutes).padStart(2, '0'); }
  get fSeconds(): string { return String(this.countdown.seconds).padStart(2, '0'); }

  tickDays():    boolean { return this.countdown.days    !== this.prevCountdown.days; }
  tickHours():   boolean { return this.countdown.hours   !== this.prevCountdown.hours; }
  tickMinutes(): boolean { return this.countdown.minutes !== this.prevCountdown.minutes; }
  tickSeconds(): boolean { return this.countdown.seconds !== this.prevCountdown.seconds; }

  // ══════════════════════════════════════════════════════════
  //  GALLERY
  // ══════════════════════════════════════════════════════════

  get galleryImages(): string[] { return this.event?.gallery || []; }
  get galleryDots():   number[] { return this.galleryImages.map((_, i) => i); }
  get galleryTranslate(): string { return `translateX(-${this.galleryIndex * 100}%)`; }

  goToSlide(n: number) {
    const len = this.galleryImages.length;
    this.galleryIndex = ((n % len) + len) % len;
    this.cdr.detectChanges();
    this.resetGalleryAuto();
  }
  prevSlide() { this.goToSlide(this.galleryIndex - 1); }
  nextSlide() { this.goToSlide(this.galleryIndex + 1); }

  private startGalleryAuto() {
    this.galleryAutoInterval = setInterval(() => {
      this.galleryIndex = (this.galleryIndex + 1) % Math.max(this.galleryImages.length, 1);
      this.cdr.detectChanges();
    }, 5500);
  }
  private resetGalleryAuto() {
    clearInterval(this.galleryAutoInterval);
    this.startGalleryAuto();
  }

  // ══════════════════════════════════════════════════════════
  //  LIGHTBOX
  // ══════════════════════════════════════════════════════════

  openLightbox(index: number) {
    this.currentIndex = index;
    this.currentImage = this.event.gallery[index];
    this.showLightbox = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }
  closeLightbox(event?: MouseEvent) {
    if (!event || (event.target as HTMLElement).classList.contains('lb-overlay')) {
      this.showLightbox = false;
      document.body.style.overflow = '';
      this.cdr.detectChanges();
    }
  }
  prevLightbox() {
    this.currentIndex = (this.currentIndex - 1 + this.event.gallery.length) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }
  nextLightbox() {
    this.currentIndex = (this.currentIndex + 1) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  // ══════════════════════════════════════════════════════════
  //  MUSIC
  // ══════════════════════════════════════════════════════════

  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) { audio.pause(); }
      else { await audio.play(); }
      this.isPlaying = !this.isPlaying;
      this.cdr.detectChanges();
    } catch (e) { console.warn(e); }
  }

  // ══════════════════════════════════════════════════════════
  //  RSVP
  // ══════════════════════════════════════════════════════════

  submitRsvp(e: Event) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name:       (form.querySelector('[name="name"]')       as HTMLInputElement).value,
      phone:      (form.querySelector('[name="phone"]')      as HTMLInputElement).value,
      guestCount: Number((form.querySelector('[name="guestCount"]') as HTMLInputElement)?.value || 1),
      attending:  (form.querySelector('[name="attending"]')  as HTMLSelectElement).value === 'true',
      eventId:    this.event._id,
    };
    this.api.submitRSVP(data).subscribe(() => {
      this.rsvpSubmitted = true;
      this.cdr.detectChanges();
      setTimeout(() => {
        this.animateBloom();
        this.triggerPetalBurst();
      }, 120);
    });
  }

  /** Animate sakura petals bursting outward in the success state */
  private animateBloom() {
    const container = this.rsBloomRef?.nativeElement;
    if (!container) return;
    const petals = ['🌸','🌺','🌷','✿','❀','🌹'];
    petals.forEach((p, i) => {
      const angle = (i / petals.length) * Math.PI * 2;
      const dist  = 38;
      const x = Math.cos(angle) * dist;
      const y = Math.sin(angle) * dist;
      const el = document.createElement('span');
      el.className = 'rs-petal';
      el.textContent = p;
      el.style.setProperty('--rs-origin', `translate(0,0) scale(0)`);
      el.style.setProperty('--rs-dest',   `translate(${x}px,${y}px) scale(1)`);
      el.style.animationDelay = (i * 0.08) + 's';
      container.appendChild(el);
    });
  }

  /** Emit petal burst from centre of screen on RSVP confirm */
  private triggerPetalBurst() {
    const canvas = this.petalCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const cx = canvas.width / 2, cy = canvas.height / 2;
    let burst: any[] = [];

    for (let i = 0; i < 30; i++) {
      const angle = (i / 30) * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      burst.push({
        x: cx, y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        life: 0, maxLife: 80,
        size: Math.random() * 12 + 6,
      });
    }

    const animBurst = () => {
      burst = burst.filter(p => {
        p.x += p.vx; p.y += p.vy; p.vy += 0.15; p.life++;
        if (p.life < p.maxLife) {
          ctx.globalAlpha = 1 - p.life / p.maxLife;
          ctx.font = p.size + 'px serif';
          ctx.fillText('🌸', p.x, p.y);
          ctx.globalAlpha = 1;
          return true;
        }
        return false;
      });
      if (burst.length) requestAnimationFrame(animBurst);
    };
    animBurst();
  }

  // ══════════════════════════════════════════════════════════
  //  SCROLL REVEAL
  // ══════════════════════════════════════════════════════════

  private initScrollReveal() {
    this.scrollObserver = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          this.scrollObserver.unobserve(e.target);
        }
      }),
      { threshold: 0.07 }
    );
    document.querySelectorAll('.fade-up').forEach(el => this.scrollObserver.observe(el));
  }

  // ══════════════════════════════════════════════════════════
  //  PETAL CANVAS — realistic bezier-curve falling petals
  //  Each petal: gradient fill, vein line, natural sway physics
  // ══════════════════════════════════════════════════════════

  private initPetalCanvas() {
    const canvas = this.petalCanvasRef.nativeElement;
    const ctx    = canvas.getContext('2d')!;
    let petals: any[] = [];

    const COLORS: [number,number,number][] = [
      [232,160,176], [244,192,204], [253,232,238], [220,130,155], [248,210,220]
    ];

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };

    const drawPetal = (x: number, y: number, w: number, h: number, angle: number, alpha: number, cidx: number) => {
      const c = COLORS[cidx];
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(x, y);
      ctx.rotate(angle);

      ctx.beginPath();
      ctx.moveTo(0, -h/2);
      ctx.bezierCurveTo( w/2, -h/2,  w/2, h/2, 0, h/2);
      ctx.bezierCurveTo(-w/2,  h/2, -w/2, -h/2, 0, -h/2);
      ctx.closePath();

      const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, w/2);
      grad.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},${alpha * 0.9})`);
      grad.addColorStop(1, `rgba(${c[0]-20},${c[1]-20},${c[2]-20},${alpha * 0.5})`);
      ctx.fillStyle = grad;
      ctx.fill();

      // Vein
      ctx.beginPath();
      ctx.moveTo(0, -h/2);
      ctx.lineTo(0, h/2);
      ctx.strokeStyle = `rgba(${c[0]+10},${c[1]+10},${c[2]+10},${alpha * 0.2})`;
      ctx.lineWidth = 0.5;
      ctx.stroke();

      ctx.restore();
    };

    const spawn = (): any => ({
      x:         Math.random() * canvas.width + 100,
      y:         -20,
      w:         Math.random() * 10 + 6,
      h:         Math.random() * 7  + 4,
      angle:     Math.random() * Math.PI * 2,
      rotSpeed:  (Math.random() - 0.5) * 0.04,
      vx:        (Math.random() - 0.6) * 1.2,
      vy:        Math.random() * 1.2 + 0.5,
      sway:      Math.random() * 0.8 + 0.4,
      swaySpeed: Math.random() * 0.02 + 0.008,
      swayPhase: Math.random() * Math.PI * 2,
      alpha:     Math.random() * 0.55 + 0.25,
      life:      0,
      cidx:      Math.floor(Math.random() * COLORS.length),
    });

    const COUNT = Math.min(70, Math.floor(window.innerWidth / 18));
    for (let i = 0; i < COUNT; i++) {
      const p = spawn();
      p.y = Math.random() * (canvas.height || 800);
      petals.push(p);
    }

    let t = 0;
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      t += 0.016;

      if (petals.length < COUNT && Math.random() < 0.3) petals.push(spawn());

      petals = petals.filter(p => {
        p.x += p.vx + Math.sin(t * p.swaySpeed * 60 + p.swayPhase) * p.sway * 0.4;
        p.y += p.vy;
        p.angle += p.rotSpeed;
        p.life++;

        const fadeIn  = Math.min(1, p.life / 60);
        const fadeOut = p.y > canvas.height * 0.85
          ? Math.max(0, 1 - (p.y - canvas.height * 0.85) / (canvas.height * 0.15))
          : 1;
        const alpha = p.alpha * fadeIn * fadeOut;

        if (alpha > 0.01) drawPetal(p.x, p.y, p.w, p.h, p.angle, alpha, p.cidx);
        return p.y < canvas.height + 30 && alpha > 0.01;
      });

      this.petalRafId = requestAnimationFrame(draw);
    };

    this.resizeFn = resize;
    window.addEventListener('resize', resize);
    this.ngZone.runOutsideAngular(() => { resize(); draw(); });
  }

  // ══════════════════════════════════════════════════════════
  //  LANTERN CANVAS — floating warm-light orbs
  // ══════════════════════════════════════════════════════════

  private initLanternCanvas() {
    const canvas = this.lanternCanvasRef.nativeElement;
    const ctx    = canvas.getContext('2d')!;
    let lanterns: any[] = [];

    const resize2 = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    window.addEventListener('resize', resize2);

    const COLORS: [number,number,number][] = [
      [212,146,30], [240,184,74], [220,100,100], [200,80,120], [180,140,220]
    ];

    const spawnLantern = (): any => {
      const c = COLORS[Math.floor(Math.random() * COLORS.length)];
      return {
        x:     Math.random() * canvas.width,
        y:     canvas.height + 20,
        r:     Math.random() * 3   + 1.5,
        vy:    -(Math.random() * 0.5 + 0.2),
        vx:    (Math.random() - 0.5) * 0.3,
        alpha: Math.random() * 0.4  + 0.15,
        phase: Math.random() * Math.PI * 2,
        glowR: Math.random() * 8   + 4,
        color: c,
      };
    };

    for (let i = 0; i < 25; i++) {
      const l = spawnLantern();
      l.y = Math.random() * (canvas.height || 800);
      lanterns.push(l);
    }

    let t = 0;
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      t += 0.016;

      if (lanterns.length < 25 && Math.random() < 0.06) lanterns.push(spawnLantern());

      lanterns = lanterns.filter(l => {
        l.x += l.vx + Math.sin(t * 0.5 + l.phase) * 0.2;
        l.y += l.vy;
        const blink = 0.5 + 0.5 * Math.sin((t * (0.8 + l.phase * 0.3) * 60 * 0.016) + l.phase);
        const a     = l.alpha * blink;
        const [r, g, b] = l.color;

        // Outer glow
        const grd = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.glowR * 2);
        grd.addColorStop(0, `rgba(${r},${g},${b},${a * 0.35})`);
        grd.addColorStop(1, 'transparent');
        ctx.beginPath(); ctx.arc(l.x, l.y, l.glowR * 2, 0, Math.PI * 2);
        ctx.fillStyle = grd; ctx.fill();

        // Core dot
        ctx.beginPath(); ctx.arc(l.x, l.y, l.r * blink, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${r},${g},${b},${a * 0.9})`;
        ctx.fill();

        return l.y > -20;
      });

      this.lanternRafId = requestAnimationFrame(draw);
    };

    this.ngZone.runOutsideAngular(() => { resize2(); draw(); });
  }
}