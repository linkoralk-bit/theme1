import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import AOS from 'aos';

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
})
export class EventComponent implements OnInit {

  event: any = null;
  mapUrl!: SafeResourceUrl;

  isPlaying = false;

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    AOS.init({ duration: 1200 });

    const slug = this.route.snapshot.paramMap.get('slug');

    this.api.getEvent(slug!).subscribe((res) => {
      this.event = res;

      // ✅ MAP FIX
      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${this.event.location}&output=embed`
      );
    });
  }

  ngAfterViewInit() {
  setTimeout(() => {
    const elements = document.querySelectorAll('.fade-section');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, { threshold: 0.2 });

    elements.forEach(el => observer.observe(el));
  }, 1000); // wait until load animation done
}

  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) {
        audio.pause();
      } else {
        await audio.play();
      }
      this.isPlaying = !this.isPlaying;
    } catch (e) {
      console.warn(e);
    }
  }

  submitForm(e: any) {
    e.preventDefault();

    const form = e.target;

    const data = {
      name: form[0].value,
      phone: form[1].value,
      attending: form[2].value === 'true',
      eventId: this.event._id,
    };

    this.api.submitRSVP(data).subscribe(() => {
      alert('RSVP Submitted!');
    });
  }
}