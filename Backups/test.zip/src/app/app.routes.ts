import { Routes } from '@angular/router';
import { EventComponent } from './pages/event/event.component';
import { HomeComponent } from './pages/home/home.component';
import { AdminComponent } from './pages/admin/admin.component';

export const routes: Routes = [
  { path: '', component: HomeComponent }, // landing page
  { path: 'event/:slug', component: EventComponent },
  { path: 'admin', component: AdminComponent }
];