import { Routes } from '@angular/router';
import { EventComponent } from './pages/event/event.component';
import { HomeComponent } from './pages/home/home.component';
import { AdminComponent } from './pages/admin/admin.component';

export const routes: Routes = [
  { path: '', redirectTo: 'event/ashen-nimali', pathMatch: 'full' },
  { path: 'event/:slug', component: EventComponent },
  { path: 'admin', component: AdminComponent }
];