import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin.component.html'
})
export class AdminComponent implements OnInit {

  events: any[] = [];
  selectedEvent: any = null;

  constructor(private admin: AdminService) {}

  ngOnInit() {
    this.loadEvents();
  }

  loadEvents() {
    this.admin.getEvents().subscribe((res: any) => {
      this.events = res;
    });
  }

  // 🔥 CREATE NEW
  createNewEvent() {
    this.selectedEvent = {
      slug: '',
      groom: '',
      bride: '',
      date: '',
      location: '',
      template: 'classic',
      gallery: [],
      story: [],
      schedule: []
    };
  }

  // 🔥 SELECT (FIXED)
  selectEvent(e: any) {
    this.selectedEvent = {
      ...JSON.parse(JSON.stringify(e)),
      gallery: e.gallery || [],
      story: e.story || [],
      schedule: e.schedule || []
    };
  }

  // 🔥 SAVE (CREATE + UPDATE)
 save() {
  const payload = {
    ...this.selectedEvent,
    gallery: this.selectedEvent.gallery || [],
    story: this.selectedEvent.story || [],
    schedule: this.selectedEvent.schedule || []
  };

  if (this.selectedEvent._id) {
    this.admin.updateEvent(this.selectedEvent._id, payload)
      .subscribe(() => {
        alert('Updated!');
        this.loadEvents();
      });
  } else {
    this.admin.createEvent(payload)
      .subscribe(() => {
        alert('Created!');
        this.loadEvents();
        this.selectedEvent = null;
      });
  }
}

  // 🔥 COPY LINK
  copyLink(slug: string) {
    navigator.clipboard.writeText(`http://localhost:4200/event/${slug}`);
    alert('Link copied!');
  }

  // 🔥 GALLERY
  addImage() {
    this.selectedEvent.gallery.push('');
  }

  removeImage(i: number) {
    this.selectedEvent.gallery.splice(i, 1);
  }

  // 🔥 STORY
  addStory() {
    this.selectedEvent.story.push({ title: '', description: '' });
  }

  removeStory(i: number) {
    this.selectedEvent.story.splice(i, 1);
  }

  // 🔥 SCHEDULE
  addSchedule() {
    this.selectedEvent.schedule.push({ name: '', time: '' });
  }

  removeSchedule(i: number) {
    this.selectedEvent.schedule.splice(i, 1);
  }
}