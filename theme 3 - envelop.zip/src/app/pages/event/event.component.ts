import {
  Component, OnInit, OnDestroy, AfterViewInit,
  ChangeDetectorRef, ChangeDetectionStrategy
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

type Phase = 'envelope' | 'opening' | 'invitation';

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventComponent implements OnInit, OnDestroy, AfterViewInit {

  event: any = null;
  mapUrl!: SafeResourceUrl;
  isPlaying = false;
  rsvpSubmitted = false;

  // Envelope reveal state machine
  phase: Phase = 'envelope';
  envelopeOpen = false;       // triggers CSS flip of top flap
  letterRising = false;       // triggers letter peek animation
  siteVisible = false;        // fades in the full invitation

  // Typewriter
  displayGroom = '';
  displayBride = '';
  private typeIntervals: any[] = [];
  private typeTimeouts:  any[] = [];

  // Countdown
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  prevCountdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  private timerInterval: any;

  // Lightbox
  showLightbox = false;
  currentIndex = 0;
  currentImage = '';

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    const slug = this.route.snapshot.paramMap.get('slug');
    this.api.getEvent(slug!).subscribe(res => {
      this.event = res;
      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${encodeURIComponent(res.location)}&output=embed`
      );
      this.cdr.detectChanges();
    });
  }

  ngAfterViewInit() {}

  // ── ENVELOPE INTERACTION ──────────────────────────────

  /** Called when user clicks the envelope */
  clickEnvelope() {
    if (this.phase !== 'envelope') return;
    this.phase = 'opening';

    // Step 1: break the wax seal, flap opens
    this.envelopeOpen = true;
    this.cdr.detectChanges();

    // Step 2: letter rises after flap is halfway open
    const t1 = setTimeout(() => {
      this.letterRising = true;
      this.cdr.detectChanges();
    }, 500);

    // Step 3: fade envelope out, fade site in
    const t2 = setTimeout(() => {
      this.siteVisible = true;
      this.phase = 'invitation';
      this.cdr.detectChanges();

      // Start typewriter + countdown now that site is visible
      this.animateNames();
      this.startCountdown();

      // After site is visible, init scroll observer
      const t3 = setTimeout(() => this.initScrollObserver(), 900);
      this.typeTimeouts.push(t3);
    }, 1800);

    this.typeTimeouts.push(t1, t2);
  }

  // ── TYPEWRITER ────────────────────────────────────────
  animateNames() {
    const groom = this.event?.groom || '';
    const bride = this.event?.bride || '';
    let i = 0;

    const gi = setInterval(() => {
      if (i < groom.length) {
        this.displayGroom += groom[i++];
        this.cdr.detectChanges();
      } else {
        clearInterval(gi);
        const t = setTimeout(() => {
          let j = 0;
          const bi = setInterval(() => {
            if (j < bride.length) {
              this.displayBride += bride[j++];
              this.cdr.detectChanges();
            } else {
              clearInterval(bi);
            }
          }, 90);
          this.typeIntervals.push(bi);
        }, 400);
        this.typeTimeouts.push(t);
      }
    }, 90);
    this.typeIntervals.push(gi);
  }

  // ── COUNTDOWN ─────────────────────────────────────────
  startCountdown() {
    const target = new Date(this.event.date + 'T16:00:00');
    const run = () => {
      const diff = target.getTime() - Date.now();
      if (diff > 0) {
        const next = {
          days:    Math.floor(diff / 86_400_000),
          hours:   Math.floor((diff % 86_400_000) / 3_600_000),
          minutes: Math.floor((diff % 3_600_000)  / 60_000),
          seconds: Math.floor((diff % 60_000)     / 1_000),
        };
        this.prevCountdown = { ...this.countdown };
        this.countdown = next;
        this.cdr.detectChanges();
      } else {
        clearInterval(this.timerInterval);
      }
    };
    run();
    this.timerInterval = setInterval(run, 1000);
  }

  get fDays():    string { return String(this.countdown.days).padStart(3, '0'); }
  get fHours():   string { return String(this.countdown.hours).padStart(2, '0'); }
  get fMinutes(): string { return String(this.countdown.minutes).padStart(2, '0'); }
  get fSeconds(): string { return String(this.countdown.seconds).padStart(2, '0'); }

  secondsTick(): boolean { return this.countdown.seconds !== this.prevCountdown.seconds; }

  // ── SCROLL OBSERVER ───────────────────────────────────
  initScrollObserver() {
    const io = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          io.unobserve(e.target);
        }
      }),
      { threshold: 0.07 }
    );
    document.querySelectorAll('.fade-up, .tl-item').forEach(el => io.observe(el));
  }

  // ── LIGHTBOX ──────────────────────────────────────────
  openLightbox(index: number) {
    this.currentIndex = index;
    this.currentImage = this.event.gallery[index];
    this.showLightbox = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }

  closeLightbox(event?: MouseEvent) {
    if (!event || (event.target as HTMLElement).classList.contains('lb-overlay')) {
      this.showLightbox = false;
      document.body.style.overflow = '';
      this.cdr.detectChanges();
    }
  }

  prevImage() {
    this.currentIndex = (this.currentIndex - 1 + this.event.gallery.length) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  nextImage() {
    this.currentIndex = (this.currentIndex + 1) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
    this.cdr.detectChanges();
  }

  // ── MUSIC ─────────────────────────────────────────────
  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) { audio.pause(); }
      else { await audio.play(); }
      this.isPlaying = !this.isPlaying;
      this.cdr.detectChanges();
    } catch (e) { console.warn(e); }
  }

  // ── RSVP ──────────────────────────────────────────────
  submitRsvp(e: Event) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name:      (form[0] as HTMLInputElement).value,
      phone:     (form[1] as HTMLInputElement).value,
      attending: (form[2] as HTMLSelectElement).value === 'true',
      eventId:   this.event._id,
    };
    this.api.submitRSVP(data).subscribe(() => {
      this.rsvpSubmitted = true;
      this.cdr.detectChanges();
    });
  }

  // ── CLEANUP ───────────────────────────────────────────
  ngOnDestroy() {
    clearInterval(this.timerInterval);
    this.typeIntervals.forEach(clearInterval);
    this.typeTimeouts.forEach(clearTimeout);
  }
}