import { Component, OnInit, OnDestroy, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit, OnDestroy, AfterViewInit {

  event: any = null;
  mapUrl!: SafeResourceUrl;
  isPlaying = false;

  // Typewriter
  displayGroom = '';
  displayBride = '';
  heroReady = false;

  // Countdown
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  prevCountdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
  private timerInterval: any;
  private typewriterTimeouts: any[] = [];

  // Lightbox
  showLightbox = false;
  currentIndex = 0;
  currentImage = '';

  // Particles
  particles: { x: number; y: number; size: number; delay: number; duration: number }[] = [];

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.generateParticles();
    const slug = this.route.snapshot.paramMap.get('slug');

    this.api.getEvent(slug!).subscribe((res) => {
      this.event = res;

      this.mapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://maps.google.com/maps?q=${encodeURIComponent(this.event.location)}&output=embed`
      );

      setTimeout(() => {
        this.heroReady = true;
        this.animateNames();
        this.startCountdown();
        this.cdr.detectChanges();
      }, 300);
    });
  }

  ngAfterViewInit() {
    setTimeout(() => this.initScrollObserver(), 1000);
  }

  generateParticles() {
    this.particles = Array.from({ length: 28 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      delay: Math.random() * 10,
      duration: Math.random() * 12 + 8
    }));
  }

  // Typewriter Animation
  animateNames() {
    const groom = this.event?.groom || '';
    const bride = this.event?.bride || '';
    let i = 0;

    const typeGroom = setInterval(() => {
      if (i < groom.length) {
        this.displayGroom += groom[i++];
        this.cdr.detectChanges();
      } else {
        clearInterval(typeGroom);
        const t = setTimeout(() => this.typeBride(bride), 500);
        this.typewriterTimeouts.push(t);
      }
    }, 100);
  }

  typeBride(bride: string) {
    let j = 0;
    const typeBride = setInterval(() => {
      if (j < bride.length) {
        this.displayBride += bride[j++];
        this.cdr.detectChanges();
      } else {
        clearInterval(typeBride);
      }
    }, 100);
  }

  // Countdown
  startCountdown() {
    const weddingDate = new Date(this.event.date + 'T16:00:00');

    this.timerInterval = setInterval(() => {
      const now = new Date().getTime();
      const distance = weddingDate.getTime() - now;

      if (distance > 0) {
        const newCountdown = {
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        };
        this.prevCountdown = { ...this.countdown };
        this.countdown = newCountdown;
        this.cdr.detectChanges();
      } else {
        clearInterval(this.timerInterval);
      }
    }, 1000);
  }

  // Scroll Observer
  initScrollObserver() {
    const elements = document.querySelectorAll('.fade-up');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    elements.forEach(el => observer.observe(el));
  }

  // Countdown formatted values
  get formattedDays(): string { return String(this.countdown.days).padStart(3, '0'); }
  get formattedHours(): string { return String(this.countdown.hours).padStart(2, '0'); }
  get formattedMinutes(): string { return String(this.countdown.minutes).padStart(2, '0'); }
  get formattedSeconds(): string { return String(this.countdown.seconds).padStart(2, '0'); }

  // Lightbox
  openLightbox(index: number) {
    this.currentIndex = index;
    this.currentImage = this.event.gallery[index];
    this.showLightbox = true;
    document.body.style.overflow = 'hidden';
  }

  closeLightbox(event?: MouseEvent) {
    if (!event || (event.target as HTMLElement).classList.contains('lightbox-overlay')) {
      this.showLightbox = false;
      document.body.style.overflow = '';
    }
  }

  prevImage() {
    this.currentIndex = (this.currentIndex - 1 + this.event.gallery.length) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
  }

  nextImage() {
    this.currentIndex = (this.currentIndex + 1) % this.event.gallery.length;
    this.currentImage = this.event.gallery[this.currentIndex];
  }

  // Music
  async toggleMusic(audio: HTMLAudioElement) {
    try {
      if (this.isPlaying) {
        audio.pause();
      } else {
        await audio.play();
      }
      this.isPlaying = !this.isPlaying;
    } catch (e) {
      console.warn('Autoplay blocked:', e);
    }
  }

  // RSVP
  rsvpSubmitted = false;
  submitForm(e: Event) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name: (form[0] as HTMLInputElement).value,
      phone: (form[1] as HTMLInputElement).value,
      attending: (form[2] as HTMLSelectElement).value === 'true',
      eventId: this.event._id,
    };

    this.api.submitRSVP(data).subscribe(() => {
      this.rsvpSubmitted = true;
      this.cdr.detectChanges();
    });
  }

  ngOnDestroy() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.typewriterTimeouts.forEach(t => clearTimeout(t));
  }
}